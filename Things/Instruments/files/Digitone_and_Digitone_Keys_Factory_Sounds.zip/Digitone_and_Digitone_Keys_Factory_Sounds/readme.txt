The Digitone Keys Bank B contains the same Sounds that are in Digitones Bank A.
If you want to install the Digitone Keys's factory Sounds on a Digitone, you only need to install the Digitone Keys Bank A Sounds.
If you want to install the Digitone's factory Sounds on a Digitone Keys you only need to install the Digitone Bank B Sounds.